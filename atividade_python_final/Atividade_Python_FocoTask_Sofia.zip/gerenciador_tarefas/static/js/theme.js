const root = document.documentElement;
const themeButton = document.getElementById("themeToggle");

function applyTheme(theme) {
    root.setAttribute("data-bs-theme", theme);
    themeButton.textContent = theme === "dark" ? "☀️" : "🌙";
    themeButton.setAttribute("aria-label", theme === "dark" ? "Ativar tema claro" : "Ativar tema escuro");
}

const savedTheme = localStorage.getItem("focotask-theme") || "light";
applyTheme(savedTheme);

themeButton.addEventListener("click", () => {
    const nextTheme = root.getAttribute("data-bs-theme") === "dark" ? "light" : "dark";
    localStorage.setItem("focotask-theme", nextTheme);
    applyTheme(nextTheme);
});
