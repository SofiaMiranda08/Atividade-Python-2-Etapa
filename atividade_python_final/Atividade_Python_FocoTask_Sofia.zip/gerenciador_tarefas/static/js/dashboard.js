async function loadProgress() {
    const canvas = document.getElementById("progressChart");
    if (!canvas || typeof Chart === "undefined") return;

    try {
        const response = await fetch("/api/progresso", { headers: { Accept: "application/json" } });
        if (!response.ok) throw new Error("Não foi possível carregar o progresso.");
        const data = await response.json();

        new Chart(canvas, {
            type: "doughnut",
            data: {
                labels: ["Pendentes", "Em andamento", "Concluídas"],
                datasets: [{
                    data: [data["pendente"], data["em andamento"], data["concluída"]],
                    backgroundColor: ["#f0ad4e", "#0d6efd", "#198754"],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: "66%",
                plugins: { legend: { position: "bottom" } }
            }
        });
    } catch (error) {
        canvas.parentElement.innerHTML = '<p class="text-body-secondary text-center py-5">Gráfico indisponível no momento.</p>';
    }
}

loadProgress();
