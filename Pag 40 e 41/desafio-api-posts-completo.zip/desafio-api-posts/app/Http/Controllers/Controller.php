<?php

namespace App\Http\Controllers;

abstract class Controller
{
    // Classe base dos controllers.
}
