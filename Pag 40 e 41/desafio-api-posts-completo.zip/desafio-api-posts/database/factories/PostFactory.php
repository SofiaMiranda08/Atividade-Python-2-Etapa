<?php

namespace Database\Factories;

use App\Models\Post;
use Illuminate\Database\Eloquent\Factories\Factory;

class PostFactory extends Factory
{
    protected $model = Post::class;

    public function definition(): array
    {
        return [
            'titulo' => fake()->sentence(5),
            'conteudo' => fake()->paragraphs(2, true),
        ];
    }
}
