import os
import sqlite3
import urllib.error
import urllib.request
import json
from functools import wraps
from pathlib import Path

from flask import (
    Flask,
    flash,
    g,
    jsonify,
    redirect,
    render_template,
    request,
    session,
    url_for,
)
from werkzeug.security import check_password_hash, generate_password_hash


BASE_DIR = Path(__file__).resolve().parent
ALLOWED_STATUSES = ("pendente", "em andamento", "concluída")


def create_app(test_config=None):
    app = Flask(__name__)
    app.config.from_mapping(
        SECRET_KEY=os.environ.get("SECRET_KEY", "troque-esta-chave-em-producao"),
        DATABASE=str(BASE_DIR / "instance" / "tarefas.db"),
    )

    if test_config:
        app.config.update(test_config)

    Path(app.config["DATABASE"]).parent.mkdir(parents=True, exist_ok=True)

    def get_db():
        if "db" not in g:
            g.db = sqlite3.connect(app.config["DATABASE"])
            g.db.row_factory = sqlite3.Row
            g.db.execute("PRAGMA foreign_keys = ON")
        return g.db

    def close_db(_error=None):
        db = g.pop("db", None)
        if db is not None:
            db.close()

    def init_db():
        db = get_db()
        with app.open_resource("schema.sql") as schema:
            db.executescript(schema.read().decode("utf-8"))

    app.teardown_appcontext(close_db)

    with app.app_context():
        init_db()

    @app.context_processor
    def inject_globals():
        return {"allowed_statuses": ALLOWED_STATUSES}

    def login_required(view):
        @wraps(view)
        def wrapped_view(**kwargs):
            if "user_id" not in session:
                flash("Faça login para acessar esta página.", "warning")
                return redirect(url_for("login"))
            return view(**kwargs)

        return wrapped_view

    def clean_text(value, max_length):
        return " ".join((value or "").strip().split())[:max_length]

    def get_user_task(task_id):
        return get_db().execute(
            "SELECT * FROM tarefas WHERE id = ? AND usuario_id = ?",
            (task_id, session["user_id"]),
        ).fetchone()

    def get_advice():
        try:
            req = urllib.request.Request(
                "https://api.adviceslip.com/advice",
                headers={"User-Agent": "GerenciadorTarefas/1.0"},
            )
            with urllib.request.urlopen(req, timeout=3) as response:
                data = json.loads(response.read().decode("utf-8"))
                return data.get("slip", {}).get("advice") or "Um passo de cada vez também é progresso."
        except (urllib.error.URLError, TimeoutError, ValueError, KeyError):
            return "Um passo de cada vez também é progresso."

    @app.route("/")
    def index():
        if "user_id" in session:
            return redirect(url_for("dashboard"))
        return redirect(url_for("login"))

    @app.route("/cadastro", methods=("GET", "POST"))
    def register():
        if "user_id" in session:
            return redirect(url_for("dashboard"))

        if request.method == "POST":
            nome = clean_text(request.form.get("nome"), 100)
            email = clean_text(request.form.get("email"), 150).lower()
            senha = request.form.get("senha", "")
            confirmar = request.form.get("confirmar_senha", "")
            error = None

            if not nome or not email or not senha:
                error = "Preencha todos os campos obrigatórios."
            elif "@" not in email or "." not in email.split("@")[-1]:
                error = "Informe um e-mail válido."
            elif len(senha) < 6:
                error = "A senha deve ter pelo menos 6 caracteres."
            elif senha != confirmar:
                error = "As senhas não coincidem."

            if error is None:
                try:
                    db = get_db()
                    db.execute(
                        "INSERT INTO usuarios (nome, email, senha_hash) VALUES (?, ?, ?)",
                        (nome, email, generate_password_hash(senha)),
                    )
                    db.commit()
                except sqlite3.IntegrityError:
                    error = "Este e-mail já está cadastrado."
                else:
                    flash("Cadastro realizado! Agora faça seu login.", "success")
                    return redirect(url_for("login"))

            flash(error, "danger")

        return render_template("register.html")

    @app.route("/login", methods=("GET", "POST"))
    def login():
        if "user_id" in session:
            return redirect(url_for("dashboard"))

        if request.method == "POST":
            email = clean_text(request.form.get("email"), 150).lower()
            senha = request.form.get("senha", "")
            user = get_db().execute(
                "SELECT * FROM usuarios WHERE email = ?", (email,)
            ).fetchone()

            if user is None or not check_password_hash(user["senha_hash"], senha):
                flash("E-mail ou senha incorretos.", "danger")
            else:
                session.clear()
                session["user_id"] = user["id"]
                session["user_name"] = user["nome"]
                flash(f"Bem-vinda, {user['nome']}!", "success")
                return redirect(url_for("dashboard"))

        return render_template("login.html")

    @app.route("/logout", methods=("POST",))
    @login_required
    def logout():
        session.clear()
        flash("Você saiu da sua conta.", "info")
        return redirect(url_for("login"))

    @app.route("/dashboard")
    @login_required
    def dashboard():
        status = request.args.get("status", "todas")
        params = [session["user_id"]]
        query = "SELECT * FROM tarefas WHERE usuario_id = ?"
        if status in ALLOWED_STATUSES:
            query += " AND status = ?"
            params.append(status)
        else:
            status = "todas"
        query += " ORDER BY criado_em DESC"
        tarefas = get_db().execute(query, params).fetchall()
        return render_template(
            "dashboard.html", tarefas=tarefas, filtro=status, conselho=get_advice()
        )

    @app.route("/tarefas/nova", methods=("GET", "POST"))
    @login_required
    def create_task():
        if request.method == "POST":
            titulo = clean_text(request.form.get("titulo"), 120)
            descricao = clean_text(request.form.get("descricao"), 1000)
            status = request.form.get("status", "pendente")

            if not titulo:
                flash("O título é obrigatório.", "danger")
            elif status not in ALLOWED_STATUSES:
                flash("Status inválido.", "danger")
            else:
                db = get_db()
                db.execute(
                    "INSERT INTO tarefas (titulo, descricao, status, usuario_id) VALUES (?, ?, ?, ?)",
                    (titulo, descricao, status, session["user_id"]),
                )
                db.commit()
                flash("Tarefa criada com sucesso!", "success")
                return redirect(url_for("dashboard"))

        return render_template("task_form.html", tarefa=None, titulo_pagina="Nova tarefa")

    @app.route("/tarefas/<int:task_id>/editar", methods=("GET", "POST"))
    @login_required
    def edit_task(task_id):
        tarefa = get_user_task(task_id)
        if tarefa is None:
            flash("Tarefa não encontrada.", "danger")
            return redirect(url_for("dashboard"))

        if request.method == "POST":
            titulo = clean_text(request.form.get("titulo"), 120)
            descricao = clean_text(request.form.get("descricao"), 1000)
            status = request.form.get("status", "")

            if not titulo:
                flash("O título é obrigatório.", "danger")
            elif status not in ALLOWED_STATUSES:
                flash("Status inválido.", "danger")
            else:
                db = get_db()
                db.execute(
                    "UPDATE tarefas SET titulo = ?, descricao = ?, status = ?, atualizado_em = CURRENT_TIMESTAMP WHERE id = ? AND usuario_id = ?",
                    (titulo, descricao, status, task_id, session["user_id"]),
                )
                db.commit()
                flash("Tarefa atualizada com sucesso!", "success")
                return redirect(url_for("dashboard"))

        return render_template("task_form.html", tarefa=tarefa, titulo_pagina="Editar tarefa")

    @app.route("/tarefas/<int:task_id>/excluir", methods=("POST",))
    @login_required
    def delete_task(task_id):
        if get_user_task(task_id) is None:
            flash("Tarefa não encontrada.", "danger")
        else:
            db = get_db()
            db.execute(
                "DELETE FROM tarefas WHERE id = ? AND usuario_id = ?",
                (task_id, session["user_id"]),
            )
            db.commit()
            flash("Tarefa excluída.", "success")
        return redirect(url_for("dashboard"))

    @app.route("/api/tarefas", methods=("GET", "POST"))
    @login_required
    def api_tasks():
        db = get_db()
        if request.method == "GET":
            rows = db.execute(
                "SELECT id, titulo, descricao, status, criado_em, atualizado_em FROM tarefas WHERE usuario_id = ? ORDER BY criado_em DESC",
                (session["user_id"],),
            ).fetchall()
            return jsonify([dict(row) for row in rows])

        data = request.get_json(silent=True) or {}
        titulo = clean_text(data.get("titulo"), 120)
        descricao = clean_text(data.get("descricao"), 1000)
        status = data.get("status", "pendente")
        if not titulo or status not in ALLOWED_STATUSES:
            return jsonify({"erro": "Título ou status inválido."}), 400
        cursor = db.execute(
            "INSERT INTO tarefas (titulo, descricao, status, usuario_id) VALUES (?, ?, ?, ?)",
            (titulo, descricao, status, session["user_id"]),
        )
        db.commit()
        return jsonify({"id": cursor.lastrowid, "mensagem": "Tarefa criada."}), 201

    @app.route("/api/tarefas/<int:task_id>", methods=("GET", "PUT", "DELETE"))
    @login_required
    def api_task_detail(task_id):
        tarefa = get_user_task(task_id)
        if tarefa is None:
            return jsonify({"erro": "Tarefa não encontrada."}), 404

        if request.method == "GET":
            return jsonify(dict(tarefa))
        if request.method == "DELETE":
            db = get_db()
            db.execute(
                "DELETE FROM tarefas WHERE id = ? AND usuario_id = ?",
                (task_id, session["user_id"]),
            )
            db.commit()
            return jsonify({"mensagem": "Tarefa excluída."})

        data = request.get_json(silent=True) or {}
        titulo = clean_text(data.get("titulo", tarefa["titulo"]), 120)
        descricao = clean_text(data.get("descricao", tarefa["descricao"]), 1000)
        status = data.get("status", tarefa["status"])
        if not titulo or status not in ALLOWED_STATUSES:
            return jsonify({"erro": "Título ou status inválido."}), 400
        db = get_db()
        db.execute(
            "UPDATE tarefas SET titulo = ?, descricao = ?, status = ?, atualizado_em = CURRENT_TIMESTAMP WHERE id = ? AND usuario_id = ?",
            (titulo, descricao, status, task_id, session["user_id"]),
        )
        db.commit()
        return jsonify({"mensagem": "Tarefa atualizada."})

    @app.route("/api/progresso")
    @login_required
    def api_progress():
        rows = get_db().execute(
            "SELECT status, COUNT(*) AS total FROM tarefas WHERE usuario_id = ? GROUP BY status",
            (session["user_id"],),
        ).fetchall()
        totals = {status: 0 for status in ALLOWED_STATUSES}
        totals.update({row["status"]: row["total"] for row in rows})
        return jsonify(totals)

    return app


app = create_app()


if __name__ == "__main__":
    app.run(debug=False)
