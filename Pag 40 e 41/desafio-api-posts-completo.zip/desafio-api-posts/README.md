# Desafio Prático — API CRUD de Posts

Projeto Laravel 12 com uma API REST completa para a entidade **Post**, formada pelos campos `titulo` e `conteudo`.

## O que foi implementado

- Model `Post` com proteção de atribuição em massa (`fillable`)
- Migration da tabela `posts`
- Controller de API com CRUD completo
- Rotas REST com `Route::apiResource`
- Validação de entrada com mensagens em português
- Banco SQLite para facilitar a execução
- Factory e seeder
- 8 testes automatizados
- Coleção do Thunder Client com POST, GET, PUT, PATCH e DELETE

## Requisitos

- PHP 8.2 ou superior, com extensão SQLite
- Composer
- VS Code e extensão Thunder Client (para os testes manuais)

## Como executar

Abra um terminal dentro da pasta do projeto e rode, na ordem:

```bash
composer install
cp .env.example .env
php artisan key:generate
```

No Windows PowerShell, substitua `cp .env.example .env` por:

```powershell
Copy-Item .env.example .env
```

Depois crie o banco e execute as migrations:

```bash
php -r "file_exists('database/database.sqlite') || touch('database/database.sqlite');"
php artisan migrate --seed
```

No Windows PowerShell, se o comando acima não funcionar:

```powershell
New-Item database/database.sqlite -ItemType File -Force
php artisan migrate --seed
```

Inicie o servidor:

```bash
php artisan serve
```

A API ficará disponível em `http://127.0.0.1:8000`.

## Endpoints

| Método | Endpoint | Função | Resposta esperada |
|---|---|---|---|
| POST | `/api/posts` | Criar post | 201 Created |
| GET | `/api/posts` | Listar posts | 200 OK |
| GET | `/api/posts/{id}` | Buscar um post | 200 OK |
| PUT | `/api/posts/{id}` | Atualizar post completo | 200 OK |
| PATCH | `/api/posts/{id}` | Atualizar parte do post | 200 OK |
| DELETE | `/api/posts/{id}` | Excluir post | 200 OK |

## JSON para criar um post

```json
{
  "titulo": "Meu primeiro post",
  "conteudo": "Este é o conteúdo do meu primeiro post."
}
```

## JSON para atualizar com PUT

```json
{
  "titulo": "Post atualizado",
  "conteudo": "Conteúdo atualizado com sucesso."
}
```

## Testes automatizados

Execute:

```bash
php artisan test
```

Os testes verificam listagem, criação, consulta individual, PUT, PATCH, DELETE, validação e erro 404.

## Importar no Thunder Client

1. Abra o Thunder Client no VS Code.
2. Entre em **Collections**.
3. Clique no menu e escolha **Import**.
4. Selecione `thunder-tests/Desafio_API_Posts.json`.
5. Execute as requisições na ordem numérica.
6. Tire um print de cada resposta para anexar à entrega.

> Importante: rode primeiro o POST, pois as demais requisições usam o post de ID 1.

## Estrutura principal

```text
app/Http/Controllers/Api/PostController.php
app/Http/Requests/StorePostRequest.php
app/Http/Requests/UpdatePostRequest.php
app/Models/Post.php
database/migrations/2026_08_04_000000_create_posts_table.php
routes/api.php
tests/Feature/PostApiTest.php
thunder-tests/Desafio_API_Posts.json
```
