import sqlite3

import pytest

from app import create_app


@pytest.fixture()
def client(tmp_path):
    app = create_app({
        "TESTING": True,
        "SECRET_KEY": "test-key",
        "DATABASE": str(tmp_path / "test.db"),
    })
    return app.test_client()


def register_and_login(client, email="sofia@example.com"):
    client.post("/cadastro", data={
        "nome": "Sofia",
        "email": email,
        "senha": "123456",
        "confirmar_senha": "123456",
    })
    return client.post("/login", data={"email": email, "senha": "123456"})


def test_protected_page_redirects_to_login(client):
    response = client.get("/dashboard")
    assert response.status_code == 302
    assert "/login" in response.headers["Location"]


def test_register_login_and_crud(client):
    response = register_and_login(client)
    assert response.status_code == 302

    response = client.post("/tarefas/nova", data={
        "titulo": "Estudar Flask",
        "descricao": "Concluir atividade",
        "status": "pendente",
    })
    assert response.status_code == 302

    tasks = client.get("/api/tarefas").get_json()
    assert len(tasks) == 1
    task_id = tasks[0]["id"]

    response = client.put(f"/api/tarefas/{task_id}", json={"status": "concluída"})
    assert response.status_code == 200
    assert client.get(f"/api/tarefas/{task_id}").get_json()["status"] == "concluída"

    response = client.delete(f"/api/tarefas/{task_id}")
    assert response.status_code == 200
    assert client.get("/api/tarefas").get_json() == []


def test_users_cannot_access_each_others_tasks(client):
    register_and_login(client, "um@example.com")
    client.post("/tarefas/nova", data={"titulo": "Privada", "status": "pendente"})
    client.post("/logout")
    register_and_login(client, "dois@example.com")
    assert client.get("/api/tarefas").get_json() == []
    assert client.get("/api/tarefas/1").status_code == 404


def test_password_is_not_stored_as_plain_text(client, tmp_path):
    register_and_login(client)
    app = client.application
    db = sqlite3.connect(app.config["DATABASE"])
    saved_password = db.execute("SELECT senha_hash FROM usuarios").fetchone()[0]
    db.close()
    assert saved_password != "123456"
    assert saved_password.startswith(("scrypt:", "pbkdf2:"))
