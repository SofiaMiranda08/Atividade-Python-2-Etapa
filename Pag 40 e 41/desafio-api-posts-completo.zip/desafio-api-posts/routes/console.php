<?php

use Illuminate\Support\Facades\Artisan;

Artisan::command('inspire', function () {
    $this->comment('API Posts pronta para uso!');
})->purpose('Exibe uma mensagem do projeto');
