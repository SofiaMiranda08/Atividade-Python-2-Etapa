<?php

namespace Tests\Feature;

use App\Models\Post;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class PostApiTest extends TestCase
{
    use RefreshDatabase;

    public function test_lista_todos_os_posts(): void
    {
        Post::factory()->count(2)->create();
        $this->getJson('/api/posts')->assertOk()->assertJsonCount(2);
    }

    public function test_cria_um_post(): void
    {
        $dados = ['titulo' => 'Meu primeiro post', 'conteudo' => 'Conteúdo do post.'];
        $this->postJson('/api/posts', $dados)
            ->assertCreated()
            ->assertJsonPath('post.titulo', 'Meu primeiro post');
        $this->assertDatabaseHas('posts', $dados);
    }

    public function test_exibe_um_post(): void
    {
        $post = Post::factory()->create();
        $this->getJson("/api/posts/{$post->id}")
            ->assertOk()
            ->assertJsonPath('id', $post->id);
    }

    public function test_atualiza_um_post_com_put(): void
    {
        $post = Post::factory()->create();
        $dados = ['titulo' => 'Título atualizado', 'conteudo' => 'Conteúdo atualizado.'];
        $this->putJson("/api/posts/{$post->id}", $dados)
            ->assertOk()
            ->assertJsonPath('post.titulo', 'Título atualizado');
        $this->assertDatabaseHas('posts', $dados);
    }

    public function test_atualiza_parcialmente_um_post_com_patch(): void
    {
        $post = Post::factory()->create();
        $this->patchJson("/api/posts/{$post->id}", ['titulo' => 'Novo título'])
            ->assertOk()
            ->assertJsonPath('post.titulo', 'Novo título');
    }

    public function test_exclui_um_post(): void
    {
        $post = Post::factory()->create();
        $this->deleteJson("/api/posts/{$post->id}")
            ->assertOk()
            ->assertJsonPath('mensagem', 'Post excluído com sucesso.');
        $this->assertDatabaseMissing('posts', ['id' => $post->id]);
    }

    public function test_valida_campos_obrigatorios(): void
    {
        $this->postJson('/api/posts', [])
            ->assertUnprocessable()
            ->assertJsonValidationErrors(['titulo', 'conteudo']);
    }

    public function test_retorna_404_quando_post_nao_existe(): void
    {
        $this->getJson('/api/posts/999')->assertNotFound();
    }
}
