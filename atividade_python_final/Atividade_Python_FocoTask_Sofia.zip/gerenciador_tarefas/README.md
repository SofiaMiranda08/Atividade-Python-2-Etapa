# FocoTask — Gerenciador de Tarefas

Projeto completo em Flask com cadastro, login, CRUD de tarefas, filtros, tema escuro, API externa de frases, gráfico Chart.js e API REST.

## Como executar

1. Abra a pasta `gerenciador_tarefas` no VS Code.
2. Abra o terminal nessa pasta.
3. Crie o ambiente virtual:

```bash
python -m venv venv
```

4. Ative o ambiente:

**Windows (PowerShell):**

```powershell
venv\Scripts\Activate.ps1
```

**Windows (Prompt de Comando):**

```bat
venv\Scripts\activate.bat
```

5. Instale as dependências:

```bash
pip install -r requirements.txt
```

6. Execute:

```bash
python app.py
```

7. Abra no navegador: `http://127.0.0.1:5000`

O banco SQLite é criado automaticamente em `instance/tarefas.db`.

## Recursos entregues

- Cadastro, login e logout com sessão.
- Senhas protegidas com hash do Werkzeug.
- Cada usuário só acessa suas próprias tarefas.
- Criar, listar, editar, alterar status e excluir tarefas.
- Filtro por status.
- Cards Bootstrap com cores por status.
- Tema claro/escuro salvo no navegador.
- Conselho motivacional da Advice Slip API com frase reserva em caso de falha.
- Gráfico de progresso usando Chart.js e uma rota JSON.
- API REST protegida por login.
- Validação dos campos, consultas parametrizadas, `SECRET_KEY` e `debug=False`.

## Rotas da API REST

Para testar pelo Postman, faça login primeiro e mantenha o cookie da sessão.

| Método | Rota | Função |
|---|---|---|
| GET | `/api/tarefas` | Lista tarefas |
| POST | `/api/tarefas` | Cria tarefa |
| GET | `/api/tarefas/<id>` | Exibe uma tarefa |
| PUT | `/api/tarefas/<id>` | Atualiza uma tarefa |
| DELETE | `/api/tarefas/<id>` | Exclui uma tarefa |
| GET | `/api/progresso` | Totais por status para o gráfico |

Exemplo de JSON para POST/PUT:

```json
{
  "titulo": "Estudar Python",
  "descricao": "Revisar Flask e SQLite",
  "status": "em andamento"
}
```

## Testes

Execute:

```bash
pytest -q
```
