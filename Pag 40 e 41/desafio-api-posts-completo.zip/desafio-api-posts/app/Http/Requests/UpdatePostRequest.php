<?php

namespace App\Http\Requests;

class UpdatePostRequest extends StorePostRequest
{
    public function rules(): array
    {
        return [
            'titulo' => ['sometimes', 'required', 'string', 'max:255'],
            'conteudo' => ['sometimes', 'required', 'string'],
        ];
    }
}
