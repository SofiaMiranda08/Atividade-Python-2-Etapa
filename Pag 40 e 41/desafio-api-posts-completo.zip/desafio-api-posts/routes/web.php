<?php

use Illuminate\Support\Facades\Route;

Route::get('/', fn () => response()->json([
    'projeto' => 'Desafio API Posts',
    'status' => 'online',
    'documentacao' => '/api/posts',
]));
